/*
  Warnings:

  - A unique constraint covering the columns `[shopDomain]` on the table `FulfillmentService` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "FulfillmentService_shopDomain_key" ON "FulfillmentService"("shopDomain");
