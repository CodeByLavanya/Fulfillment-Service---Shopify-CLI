-- CreateTable
CREATE TABLE "CarrierService" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shopDomain" TEXT NOT NULL,
    "carrierId" TEXT NOT NULL,
    "name" TEXT,
    "callbackUrl" TEXT,
    "status" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "CarrierService_carrierId_key" ON "CarrierService"("carrierId");
