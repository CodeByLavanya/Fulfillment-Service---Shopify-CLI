-- CreateTable
CREATE TABLE "StepComplete" (
    "shopDomain" TEXT NOT NULL PRIMARY KEY,
    "stepComplete" INTEGER NOT NULL DEFAULT 0
);
