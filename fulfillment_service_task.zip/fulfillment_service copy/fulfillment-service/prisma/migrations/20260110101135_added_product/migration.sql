-- CreateTable
CREATE TABLE "AddedProduct" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "AddedProduct_shop_productId_key" ON "AddedProduct"("shop", "productId");
