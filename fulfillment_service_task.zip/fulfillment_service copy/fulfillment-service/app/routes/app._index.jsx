import { useNavigate } from "react-router";

export default function Index() {
  const navigate = useNavigate();

  const setCarrier = async () => {
    try {
      const carrierResponse = await fetch("/api/carrierService", {
        method: "POST",
      });

      const carrierResult = await carrierResponse.json();
      console.log("Response:", carrierResult);

      const fulfillmentResponse = await fetch("/api/fulFillmentService", {
        method: "POST",
      });

      const fulfillmentResult = await fulfillmentResponse.json();
      console.log("Response:", fulfillmentResult);

      console.log("start hooks");
      const webhookResponse = await fetch("/webhooks/app/orders/create", {
        method: "POST",
      });

      const webhookResult = await webhookResponse.json();

      if (webhookResult.success) {
        if (webhookResult.alreadyExists) {
          console.log(
            "ORDERS_CREATE webhook already exists with ID:",
            webhookResult.webhookId,
          );
        } else {
          console.log(
            "Created ORDERS_CREATE webhook with ID:",
            webhookResult.webhookId,
          );
        }
      } else {
        console.error("Failed to create webhook:", webhookResult.errors);
      }
      // const stepComplete = await fetch("/api/step-complete", {
      //   method: "POST",
      // });
      // const json = await stepComplete.json();

      // console.log("json,", json);

      navigate("/addProductPage");
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <s-page heading="Shopify app template">
      <s-section>
        <ul>
          <li>Create a Carrier Service</li>
          <li>Create a Fulfillment Service</li>
          <li>Register an Order Created webhook</li>
        </ul>
        <s-button variant="primary" onClick={setCarrier}>
          Setup and Continue
        </s-button>
      </s-section>
    </s-page>
  );
}
