import prisma from "../db.server";
import { authenticate } from "../shopify.server";

export const action = async ({ request }) => {
  console.log("kkkkkkkjjjjj");
  console.log("prisma", prisma);
  if (request.method !== "POST") {
    return ({ success: false, error: "Method not allowed" }, { status: 405 });
  }

  try {
    console.log("kkkkkkk");
    const { session } = await authenticate.admin(request);
    const shop = session.shop;
    console.log("shop", shop);
    const record = await prisma.stepComplete.upsert({
      where: {
        shopDomain: shop,
      },
      update: {
        stepComplete: 1,
      },
      create: {
        shopDomain: shop,
        stepComplete: 1,
      },
    });

    return {
      success: true,
      shopDomain: record.shopDomain,
      stepComplete: record.stepComplete,
    };
  } catch (error) {
    console.error("Error updating stepComplete:", error);
    return (
      { success: false, error: "Internal server error" },
      { status: 500 }
    );
  }
};
