const express = require("express");
const app = express();
const port = 3000;
app.use(express.json());
const cors = require("cors");
app.use(cors());

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.post("/api/carrierService", (req, res) => {
  try {
    console.log("Carrier Service Called");
    console.log(JSON.stringify(req.body, null, 2));

    const items = req.body.rate?.items || [];

    const totalQuantity = items.reduce((sum, item) => sum + (item.quantity || 0), 0);

    console.log("total", items);

    let shippingRates = [];

    if (totalQuantity === 1) {
      shippingRates.push({
        service_name: "Standard Delivery",
        service_code: "STANDARD",
        total_price: "0",
        currency: "USD",
        description: "Free delivery in 4 days",
      });
    } else if (totalQuantity === 2) {
      shippingRates.push(
        {
          service_name: "Standard Delivery",
          service_code: "STANDARD",
          total_price: "0",
          currency: "USD",
          description: "Free delivery in 4 days",
        },
        {
          service_name: "Moderate Delivery",
          service_code: "MODERATE",
          total_price: "500",
          currency: "USD",
          description: "Delivered in 2 days",
        },
      );
    } else if (totalQuantity > 2) {
      shippingRates.push(
        {
          service_name: "Standard Delivery",
          service_code: "STANDARD",
          total_price: "0",
          currency: "USD",
          description: "Free delivery in 4 days",
        },
        {
          service_name: "Moderate Delivery",
          service_code: "MODERATE",
          total_price: "500",
          currency: "USD",
          description: "Delivered in 2 days",
        },
        {
          service_name: "Fast Delivery",
          service_code: "FAST",
          total_price: "1000",
          currency: "USD",
          description: "Next day delivery",
        },
      );
    }

    return res.status(200).json({
      rates: shippingRates,
    });
  } catch (error) {
    console.error("Carrier Service Error:", error);
    return res.status(500).json({ error: "Carrier Service failed" });
  }
});

app.post("/api/fulFillmentService", (req, res) => {
  const userData = "FulFillment service Created SuccessFully";
  console.log("Received user data:", userData);

  res.status(201).json({
    message: "User created successfully",
    user: userData,
  });
});

app.post("/api/request-fulfillment", (req, res) => {
  const { orderId, lineItems } = req.body;

  if (!lineItems || lineItems.length === 0) {
    return res.status(400).json({ error: "No line items provided" });
  }

  if (lineItems.length === 1) {
    return res.status(400).json({
      error: "Fulfillment rejected: only 1 line item",
    });
  }

  console.log("Fulfillment request accepted for order:", orderId);

  return res.status(200).json({
    status: "accepted",
    orderId,
  });
});

app.post("/api/fulfill-order", async (req, res) => {
  try {
    const { orderId, lineItems } = req.body;

    console.log("Received /api/fulfill-order", { orderId, lineItems });

    if (!Array.isArray(lineItems) || lineItems.length === 0) {
      return res.status(400).json({ error: "No line items provided" });
    }

    if (lineItems.length === 1) {
      return res.status(400).json({
        error: "Fulfillment rejected: only 1 line item",
      });
    }

    const tracking = {
      company: "DHL",
      number: "DHL-" + Date.now(),
      url: "https://dhl.com/track/" + Date.now(),
    };

    console.log("Fulfillment CREATED (fake) for order set:", orderId);
    console.log("Tracking:", tracking);

    return res.status(200).json({
      trackingUrl: tracking.url,
      carrier: tracking.company,
      trackingNumber: tracking.number,
    });
  } catch (err) {
    console.error("Error in /api/fulfill-order:", err);
    res.status(500).json({ error: "Fulfillment failed" });
  }
});

app.post("/webhooks/orders/create", (req, res) => {
  console.log("Received ORDERS_CREATE webhook");
  const rawBody = req.body;
  console.log(rawBody);
  res.status(200).send("OK");
});

app.post("/api/inventory", (req, res) => {
  const { sku, pro } = req.body;

  if (!sku) {
    return res.status(400).json({ error: "SKU is required" });
  }

  let inventory = 1;

  // if (sku.length >= 4 && isNaN(sku)) {
  if (sku.length > 0) {
    inventory = Number(sku.length) * 2;
  }

  return res.status(200).json({
    sku,
    inventory,
    pro,
  });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
