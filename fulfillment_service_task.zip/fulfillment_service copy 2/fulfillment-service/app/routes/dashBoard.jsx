import { useNavigate } from "react-router";
import { AppProvider } from "@shopify/shopify-app-react-router/react";

export default function DashBoard() {
  const navigate = useNavigate();

  const productPage = () => {
    navigate("/dashBoardProductPage");
  };
  const orderPage = () => {
    navigate("/orderPage");
  };
  return (
    <div>
      <AppProvider>
      <s-page>
        <s-section>
          <s-button onClick={productPage}>Product Page</s-button>
          <s-button onClick={orderPage}>OrderPage</s-button>
        </s-section>
      </s-page>
      <s-app-nav>
        <s-link href="/dashBoardProductPage">Product Page</s-link>
        <s-link href="/orderPage">OrderPage</s-link>
      </s-app-nav>
      </AppProvider>
    </div>
  );
}
