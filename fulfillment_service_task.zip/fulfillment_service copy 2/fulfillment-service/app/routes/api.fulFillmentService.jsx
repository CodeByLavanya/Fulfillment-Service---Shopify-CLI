import { authenticate } from "../shopify.server";
import prisma from "../db.server";

export const action = async ({ request }) => {
  console.log("Fulfillment service create started");

  const { admin, session } = await authenticate.admin(request);

  const response = await admin.graphql(
    `#graphql
    mutation fulfillmentServiceCreate(
      $name: String!
      $callbackUrl: URL!
    ) {
      fulfillmentServiceCreate(name: $name, callbackUrl: $callbackUrl) {
        fulfillmentService {
          id
          serviceName
          callbackUrl
        }
        userErrors {
          field
          message
        }
      }
    }
  `,
    {
      variables: {
        name: "fulfillment_service",
        callbackUrl:
          "https://lori-filamentous-seemly.ngrok-free.dev/api/fulFillmentService",
      },
    },
  );

  const json = await response.json();
  //   console.log(
  //     "fulfillmentServiceCreate response:",
  //     JSON.stringify(json, null, 2),
  //   );

  const payload = json.data?.fulfillmentServiceCreate;
  const firstError = payload?.userErrors?.[0];
  const fulfillmentService = payload?.fulfillmentService || null;

  if (!firstError && fulfillmentService) {
    await prisma.fulfillmentService.upsert({
      where: {
        id: fulfillmentService.id,
      },
      update: {
        shopDomain: session.shop,
        name: fulfillmentService.serviceName,
        callbackUrl: fulfillmentService.callbackUrl,
      },
      create: {
        id: fulfillmentService.id,
        shopDomain: session.shop,
        name: fulfillmentService.serviceName,
        callbackUrl: fulfillmentService.callbackUrl,
      },
    });

    return {
      fulfillmentServiceId: fulfillmentService.id,
      status: "created",
    };
  }

  const errorMessage = firstError?.message;
  // console.log("Fulfillment service create error:", errorMessage);

  // Handle "Name has already been taken" case
  if (errorMessage === "Name has already been taken") {
    const queryRes = await admin.graphql(
      `#graphql
      query FulfillmentServicesList {
        shop {
          fulfillmentServices {
            id
            serviceName
            callbackUrl
          }
        }
      }
    `,
    );

    const queryJson = await queryRes.json();
    // console.log(
    //   "FulfillmentServicesList response:",
    //   JSON.stringify(queryJson, null, 2),
    // );

    const services = queryJson.data?.shop?.fulfillmentServices || [];
    // console.log("services>>>>>>>>>>>", services); 

    const existingService = services.find(
      (svc) =>
        svc.serviceName === "fulfillment_service" ||
        svc.callbackUrl ===
          "https://lori-filamentous-seemly.ngrok-free.dev/api/fulFillmentService",
    );

    if (existingService) {
      await prisma.fulfillmentService.upsert({
        where: {
          id: existingService.id,
        },
        update: {
          shopDomain: session.shop,
          name: existingService.serviceName,
          callbackUrl: existingService.callbackUrl,
        },
        create: {
          id: existingService.id,
          shopDomain: session.shop,
          name: existingService.serviceName,
          callbackUrl: existingService.callbackUrl,
        },
      });

      return {
        fulfillmentServiceId: existingService.id,
        status: "already_exists",
      };
    }

    return {
      error:
        "Name already taken but existing service not found in shop.fulfillmentServices.",
    };
  }

  return {
    error: errorMessage || "Unknown error creating fulfillment service",
  };
};
