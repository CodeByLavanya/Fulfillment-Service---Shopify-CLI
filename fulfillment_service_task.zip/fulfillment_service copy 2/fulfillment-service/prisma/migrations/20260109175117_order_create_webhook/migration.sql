/*
  Warnings:

  - You are about to drop the `WebhookSubscription` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
PRAGMA foreign_keys=off;
DROP TABLE "WebhookSubscription";
PRAGMA foreign_keys=on;

-- CreateTable
CREATE TABLE "OrderCreateWebhook" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shopDomain" TEXT NOT NULL,
    "topic" TEXT NOT NULL,
    "uri" TEXT NOT NULL,
    "webhookGid" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "OrderCreateWebhook_shopDomain_topic_key" ON "OrderCreateWebhook"("shopDomain", "topic");
