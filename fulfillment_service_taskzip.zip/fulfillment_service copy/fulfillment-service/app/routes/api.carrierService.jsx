import { authenticate } from "../shopify.server";
import prisma from "../db.server";

export const action = async ({ request }) => {
  console.log("carrier server run");
  // console.log("prisma", prisma);
  const { admin, session } = await authenticate.admin(request);
  const response = await admin.graphql(
    `#graphql
  mutation CarrierServiceCreate($input: DeliveryCarrierServiceCreateInput!) {
    carrierServiceCreate(input: $input) {
      carrierService {
        id
        name
        callbackUrl
        active
        supportsServiceDiscovery
      }
      userErrors {
        field
        message
      }
    }
  }`,
    {
      variables: {
        input: {
          name: "carrier service",
          callbackUrl:
            "https://lori-filamentous-seemly.ngrok-free.dev/api/carrierService",
          supportsServiceDiscovery: true,
          active: true,
        },
      },
    },
  );
  const json = await response.json();
  const payload = json.data?.carrierServiceCreate;

  const errorMessage = payload?.userErrors?.[0]?.message;

  if (!errorMessage) {
    const carrier = json.data.carrierServiceCreate.carrierService;

    const savedCarrier = await prisma.carrierService.upsert({
      where: {
        carrierId: carrier.id,
      },
      update: {
        name: carrier.name,
        callbackUrl: carrier.callbackUrl,
        status: "created",
        shopDomain: session.shop,
      },
      create: {
        carrierId: carrier.id,
        name: carrier.name,
        callbackUrl: carrier.callbackUrl,
        status: "created",
        shopDomain: session.shop,
      },
    });

    return {
      carrierServiceId: savedCarrier.carrierId,
      status: "created",
    };
  }

  if (errorMessage === "carrier service is already configured") {
    const queryRes = await admin.graphql(
      `#graphql
      query {
        carrierServices(first: 5) {
          edges {
            node {
              id
              name
              callbackUrl
            }
          }
        }
      }`,
    );

    const queryJson = await queryRes.json();
    const existingCarrier = queryJson.data.carrierServices.edges[0].node;

    // console.log("stttttarrtyyuuii");

    const savedCarrier = await prisma.carrierService.upsert({
      where: {
        carrierId: existingCarrier.id,
      },
      update: {
        name: existingCarrier.name,
        callbackUrl: existingCarrier.callbackUrl,
        status: "already_exists",
        shopDomain: session.shop,
      },
      create: {
        carrierId: existingCarrier.id,
        name: existingCarrier.name,
        callbackUrl: existingCarrier.callbackUrl,
        status: "already_exists",
        shopDomain: session.shop,
      },
    });

    return {
      carrierServiceId: savedCarrier.carrierId,
      status: "already_exists",
    };
  }

  return { error: errorMessage };
};

// gid://shopify/DeliveryCarrierService/76305989821
