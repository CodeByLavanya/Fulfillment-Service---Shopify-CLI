import { useLoaderData } from "react-router";
import { useState, useMemo } from "react";
import { authenticate } from "../shopify.server";
import { useFetcher } from "react-router";
import { useNavigate } from "react-router";
import prisma from "../db.server";
import Styles from "./src/Styles.module.css";
import { AppProvider } from "@shopify/shopify-app-react-router/react";

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const response = await admin.graphql(
    `#graphql
    query ListProductsForExclusions {
      products(first: 120) {
        nodes {
          id
          title
          featuredImage {
            url
            altText
          }
        }
      }
    }
  `,
  );

  const data = await response.json();

  const nodes =
    data.data?.products?.nodes?.map((node) => ({
      id: node.id,
      title: node.title,
      featuredImage: node.featuredImage || null,
    })) || [];
  const addedProducts = await prisma.addedProduct.findMany({
    where: { shop },
    select: { productId: true },
  });

  const addedIds = addedProducts.map((p) => p.productId);

  return { products: nodes, addedIds };
}

export async function action({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const formData = await request.formData();
  const addedIds = JSON.parse(formData.get("addedIds") || "[]");

  await prisma.addedProduct.deleteMany({
    where: { shop },
  });

  if (addedIds.length > 0) {
    await prisma.addedProduct.createMany({
      data: addedIds.map((productId) => ({
        shop,
        productId,
      })),
    });
  }

  const FulfillmenId = await prisma.fulfillmentService.findFirst({
    where: {
      shopDomain: shop,
    },
    select: {
      id: true,
    },
  });
  console.log("fulfilll>>>>>>>>>>>", FulfillmenId);

  const fsResponse = await admin.graphql(
    `#graphql
     query FulfillmentServiceShow($id: ID!) {
       fulfillmentService(id: $id) {
         id
         location {
           id
         }
       }
     }`,
    {
      variables: {
        id: FulfillmenId.id,
      },
    },
  );

  const fsJson = await fsResponse.json();
  const locationId = fsJson.data?.fulfillmentService?.location?.id;

  if (!locationId) {
    console.error("Fulfillment service has no location", fsJson);
    throw new Error("No location on fulfillment service");
  }

  const allInventoryItemIds = [];

  for (const productGid of addedIds) {
    const prodRes = await admin.graphql(
      `#graphql
       query GetProductWithInventory($id: ID!) {
         product(id: $id) {
           id
           variants(first: 50) {
             nodes {
               id
               inventoryItem {
                 id
               }
             }
           }
         }
       }`,
      {
        variables: { id: productGid },
      },
    );

    const prodJson = await prodRes.json();
    const variants = prodJson.data?.product?.variants?.nodes ?? [];

    const inventoryItemIdsForProduct = variants
      .map((v) => v.inventoryItem?.id)
      .filter(Boolean);

    allInventoryItemIds.push(...inventoryItemIdsForProduct);
  }
  console.log("locationId", locationId);

  for (const inventoryItemId of allInventoryItemIds) {
    const activateResponse = await admin.graphql(
      `#graphql
     mutation ActivateInventoryItemAtLocation($inventoryItemId: ID!, $locationId: ID!) {
       inventoryActivate(inventoryItemId: $inventoryItemId, locationId: $locationId) {
         inventoryLevel {
           id
         }
       }
     }`,
      {
        variables: {
          inventoryItemId,
          locationId,
        },
      },
    );

    const activateJson = await activateResponse.json();

    const activateErrors =
      activateJson.errors ??
      activateJson.data?.inventoryActivate?.userErrors ??
      [];

    if (activateErrors.length) {
      console.error("Error activating inventory item", {
        inventoryItemId,
        locationId,
        errors: activateErrors,
      });
    }
  }

  const quantities = allInventoryItemIds.map((inventoryItemId) => ({
    inventoryItemId,
    locationId: locationId,
    quantity: 10,
  }));

  const invResponse = await admin.graphql(
    `#graphql
     mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
       inventorySetQuantities(input: $input) {
         inventoryAdjustmentGroup {
           reason
           changes {
             name
             delta
             quantityAfterChange
           }
         }
         userErrors {
           code
           field
           message
         }
       }
     }`,
    {
      variables: {
        input: {
          name: "available",
          reason: "correction",
          ignoreCompareQuantity: true,
          quantities,
        },
      },
    },
  );

  const invJson = await invResponse.json();
  const userErrors = invJson.data?.inventorySetQuantities?.userErrors ?? [];
  console.log(invJson.data?.inventorySetQuantities?.inventoryAdjustmentGroup);

  if (userErrors.length) {
    console.error("Inventory update errors:", userErrors);
    return { ok: false, userErrors };
  }

  return { ok: true };
}

export default function ProductPage() {
  const data = useLoaderData() || {};
  const fetcher = useFetcher();
  const navigate = useNavigate();
  const products = Array.isArray(data.products) ? data.products : [];
  const initialAddedIds = Array.isArray(data.addedIds) ? data.addedIds : [];

  const [activeTab, setActiveTab] = useState("all");
  const [selectedIds, setSelectedIds] = useState([]);
  const [addedIds, setAddedIds] = useState(initialAddedIds);
  const [searchQuery, setSearchQuery] = useState("");

  const continueBtn = async () => {
    try {
      const response = await fetch("/api/step-complete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ stepComplete: 2 }),
      });

      const result = await response.json();
      console.log("step updated:", result);

      if (result.success) {
        navigate("/dashBoard");
      }
    } catch (error) {
      console.error("Failed to update stepComplete", error);
    }
  };

  // if (products.length > 0) {
  //   navigate("/dashBoard");
  // }

  const handleToggleSelect = (productId) => {
    setSelectedIds((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId],
    );
  };

  const handleAddProducts = async () => {
    const nextArray = Array.from(new Set([...addedIds, ...selectedIds]));

    setAddedIds(nextArray);
    setSelectedIds([]);

    const formData = new FormData();
    formData.append("addedIds", JSON.stringify(nextArray));

    fetcher.submit({ addedIds: JSON.stringify(nextArray) }, { method: "POST" });
  };

  const isAllTab = activeTab === "all";

  const visibleProducts = useMemo(() => {
    const baseList = isAllTab
      ? products.filter((p) => !addedIds.includes(p.id))
      : products.filter((p) => addedIds.includes(p.id));

    if (!searchQuery.trim()) return baseList;

    const lower = searchQuery.toLowerCase();
    return baseList.filter((p) => p.title.toLowerCase().includes(lower));
  }, [isAllTab, products, addedIds, searchQuery]);

  return (
    <AppProvider>
      <s-section>
        <s-stack direction="inline" gap="small-100" alignItems="center">
          <s-button
            variant={isAllTab ? "primary" : "secondary"}
            onClick={() => setActiveTab("all")}
          >
            All products
          </s-button>
          <s-button
            variant={!isAllTab ? "primary" : "secondary"}
            onClick={() => setActiveTab("added")}
          >
            Added products
          </s-button>
        </s-stack>

        <s-heading>{isAllTab ? "All products" : "Added products"}</s-heading>

        <s-box>
          {isAllTab && (
            <div className={Styles.searchRow}>
              <s-search-field
                label="Search products"
                placeholder="Search by product title"
                value={searchQuery}
                onInput={(event) => setSearchQuery(event.currentTarget.value)}
              />
            </div>
          )}

          {visibleProducts.length === 0 ? (
            <s-text color="subdued">
              {isAllTab
                ? "No products found."
                : "No products have been added yet."}
            </s-text>
          ) : (
            <s-stack gap="small-100">
              {visibleProducts.map((product) => {
                const isChecked = selectedIds.includes(product.id);

                return (
                  <s-box
                    key={product.id}
                    border="base"
                    borderRadius="base"
                    padding="small-100"
                  >
                    <s-stack
                      direction="inline"
                      alignItems="center"
                      justifyContent="space-between"
                      gap="base"
                    >
                      <div className={Styles.pro_left}>
                        {isAllTab && (
                          <s-checkbox
                            checked={isChecked}
                            onChange={() => handleToggleSelect(product.id)}
                            accessibilityLabel={`Select ${product.title}`}
                          />
                        )}

                        <s-thumbnail
                          size="small"
                          src={product.featuredImage?.url ?? ""}
                          alt={product.featuredImage?.altText ?? product.title}
                        />
                        <s-text>{product.title}</s-text>
                      </div>
                    </s-stack>
                  </s-box>
                );
              })}
            </s-stack>
          )}

          {isAllTab && (
            <s-box>
              <s-button
                variant="secondary"
                type="button"
                onClick={handleAddProducts}
                disabled={selectedIds.length === 0}
              >
                Add product
              </s-button>
              <s-button onClick={continueBtn}>Continue</s-button>
            </s-box>
          )}
        </s-box>
      </s-section>
    </AppProvider>
  );
}
