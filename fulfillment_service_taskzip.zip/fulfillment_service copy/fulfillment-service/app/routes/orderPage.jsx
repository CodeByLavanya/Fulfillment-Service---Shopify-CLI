
import prisma from "../db.server";
import { authenticate } from "../shopify.server";
import { useLoaderData, useFetcher } from "react-router";
import { AppProvider } from "@shopify/shopify-app-react-router/react";

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const fulfillmentServiceIdPrisma = await prisma.fulfillmentService.findFirst({
    where: { shopDomain: shop },
  });

  if (!fulfillmentServiceIdPrisma) {
    throw new Error("No fulfillment service configured for this shop.");
  }

  const addedProducts = await prisma.addedProduct.findMany({
    where: { shop },
  });
  const addedProductIds = new Set(addedProducts.map((ap) => ap.productId));

  const ordersResponse = await admin.graphql(
    `#graphql
    query getOrdersWithInventoryItem {
      orders(first: 100) {
        edges {
          node {
            id
            name
            lineItems(first: 250) {
              edges {
                node {
                  name
                  quantity
                  sku
                  product {
                    id
                    title
                  }
                  variant {
                    id
                    inventoryItem {
                      id
                    }
                  }
                }
              }
            }
          }
        }
      }
    }`,
  );

  const ordersJson = await ordersResponse.json();
  const ordersEdges = ordersJson.data?.orders?.edges || [];

  const fulfillmentServiceId = fulfillmentServiceIdPrisma.id;
  if (!fulfillmentServiceId) {
    throw new Error("FULFILLMENT_SERVICE_ID not available");
  }

  const locationIdResponse = await admin.graphql(
    `#graphql
    query FulfillmentServiceShow($id: ID!) {
      fulfillmentService(id: $id) {
        id
        location {
          id
        }
      }
    }`,
    {
      variables: {
        id: fulfillmentServiceId,
      },
    },
  );

  const locationJson = await locationIdResponse.json();
  const location = locationJson.data?.fulfillmentService?.location?.id;

  if (!location) {
    throw new Error("No location found for fulfillment service");
  }

  const fulfillmentResponse = await admin.graphql(
    `#graphql
    query getProductsInventoryByLocation($locationId: ID!) {
      inventoryItems(first: 130) {
        edges {
          node {
            id
            sku
            variant {
              id
              product {
                id
                title
              }
            }
            inventoryLevel(locationId: $locationId) {
              id
              location {
                id
                name
              }
              quantities(names: ["available"]) {
                name
                quantity
              }
            }
          }
        }
      }
    }`,
    {
      variables: {
        locationId: location,
      },
    },
  );

  const fulfillmentJson = await fulfillmentResponse.json();
  const fulfillmentEdges = fulfillmentJson.data?.inventoryItems?.edges || [];

  const fulfillmentByInventoryItemId = new Map();

  for (const edge of fulfillmentEdges) {
    const node = edge.node;
    const level = node.inventoryLevel;
    if (!level) continue;

    const availableEntry =
      (level.quantities || []).find((q) => q.name === "available") || null;

    fulfillmentByInventoryItemId.set(node.id, {
      inventoryItemId: node.id,
      sku: node.sku,
      productId: node.variant?.product?.id,
      productTitle: node.variant?.product?.title,
      locationId: level.location.id,
      locationName: level.location.name,
      available: availableEntry?.quantity ?? 0,
    });
  }

  const ordersWithCounts = ordersEdges.map((edge) => {
    const order = edge.node;
    const lineItemEdges = order.lineItems?.edges || [];

    let lineItemCount = 0;
    let totalQuantity = 0;

    const matchingLineItems = [];

    for (const lineEdge of lineItemEdges) {
      const lineItem = lineEdge.node;
      const inventoryItemId = lineItem.variant?.inventoryItem?.id;
      const productId = lineItem.product?.id;

      if (
        !inventoryItemId ||
        !fulfillmentByInventoryItemId.has(inventoryItemId)
      ) {
        continue;
      }

      const fulfillmentInfo = fulfillmentByInventoryItemId.get(inventoryItemId);

      if (fulfillmentInfo.available === 0) {
        continue;
      }

      if (!productId || !addedProductIds.has(productId)) {
        continue;
      }

      lineItemCount += 1;
      totalQuantity += lineItem.quantity || 0;

      matchingLineItems.push({
        name: lineItem.name,
        quantity: lineItem.quantity,
        sku: lineItem.sku,
        productId,
        productTitle: lineItem.product?.title,
        inventoryItemId,
        locationId: fulfillmentInfo.locationId,
        locationName: fulfillmentInfo.locationName,
        availableAtLocation: fulfillmentInfo.available,
      });
    }

    return {
      id: order.id,
      name: order.name,
      lineItemCount,
      totalQuantity,
      lineItems: matchingLineItems,
    };
  });

  await prisma.orderProduct.deleteMany({
    where: { shop },
  });

  const orderProductRows = ordersWithCounts.flatMap((order) =>
    order.lineItems.map((line) => ({
      shop,
      orderId: order.id,
      orderName: order.name,
      productId: line.productId,
      productTitle: line.productTitle ?? line.name,
      sku: line.sku,
      quantity: line.quantity ?? 0,
      inventoryItemId: line.inventoryItemId,
      locationId: line.locationId,
      locationName: line.locationName,
    })),
  );

  if (orderProductRows.length > 0) {
    await prisma.orderProduct.createMany({
      data: orderProductRows,
    });
  }

  return { ordersWithCounts };
}

export async function action({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const { orderId, lineItems } = await request.json();

  if (!orderId || !Array.isArray(lineItems)) {
    return new Response(JSON.stringify({ error: "Invalid request" }), {
      status: 400,
    });
  }

  if (lineItems.length === 1) {
    return new Response(
      JSON.stringify({ error: "Fulfillment rejected: only 1 line item" }),
      { status: 400 },
    );
  }

  const validLineItems = [];
  for (const line of lineItems) {
    const productId = line.productId;
    if (!productId) continue;

    const exists = await prisma.addedProduct.findFirst({
      where: {
        shop,
        productId,
      },
    });

    if (exists) {
      validLineItems.push(line);
    }
  }

  if (validLineItems.length === 0) {
    return new Response(
      JSON.stringify({
        error: "No line items in your app inventory (AddedProduct) to fulfill.",
      }),
      { status: 400 },
    );
  }

  const fulfillmentOrdersRes = await admin.graphql(
    `#graphql
    query GetFulfillmentOrdersWithLineItems($orderId: ID!) {
      order(id: $orderId) {
        id
        fulfillmentOrders(first: 100) {
          nodes {
            id
            lineItems(first: 100) {
              edges {
                node {
                  id
                  remainingQuantity
                  lineItem {
                    id
                    sku
                    quantity
                    product {
                      id
                    }
                  }
                }
              }
            }
          }
        }
      }
    }`,
    { variables: { orderId } },
  );

  const fulfillmentOrdersJson = await fulfillmentOrdersRes.json();
  const fulfillmentOrder =
    fulfillmentOrdersJson.data?.order?.fulfillmentOrders?.nodes?.[0];

  if (!fulfillmentOrder) {
    return new Response(
      JSON.stringify({ error: "No fulfillment order found" }),
      { status: 400 },
    );
  }

  const fulfillmentServiceIdPrisma = await prisma.fulfillmentService.findFirst({
    where: { shopDomain: shop },
  });

  if (!fulfillmentServiceIdPrisma?.id) {
    return new Response(
      JSON.stringify({
        error: "No FULFILLMENT_SERVICE_ID.",
      }),
      { status: 500 },
    );
  }

  const locationIdResponse = await admin.graphql(
    `#graphql
    query FulfillmentServiceShow($id: ID!) {
      fulfillmentService(id: $id) {
        id
        location {
          id
        }
      }
    }`,
    {
      variables: {
        id: fulfillmentServiceIdPrisma.id,
      },
    },
  );

  const locationJson = await locationIdResponse.json();
  const newLocationId = locationJson.data?.fulfillmentService?.location?.id;

  if (!newLocationId) {
    return new Response(
      JSON.stringify({
        error: "No target location found for fulfillment service",
      }),
      { status: 400 },
    );
  }

  const moveRes = await admin.graphql(
    `#graphql
    mutation moveFulfillmentOrderToLocation(
      $fulfillmentOrderId: ID!
      $newLocationId: ID!
    ) {
      fulfillmentOrderMove(id: $fulfillmentOrderId, newLocationId: $newLocationId) {
        movedFulfillmentOrder {
          id
          status
        }
        originalFulfillmentOrder {
          id
          status
        }
        remainingFulfillmentOrder {
          id
          status
        }
        userErrors {
          field
          message
        }
      }
    }`,
    {
      variables: {
        fulfillmentOrderId: fulfillmentOrder.id,
        newLocationId,
      },
    },
  );

  const moveJson = await moveRes.json();
  const moveErrors = moveJson.data?.fulfillmentOrderMove?.userErrors || [];

  if (moveErrors.length > 0) {
    return new Response(JSON.stringify({ error: moveErrors[0].message }), {
      status: 400,
    });
  }

  const movedFulfillmentOrderId =
    moveJson.data?.fulfillmentOrderMove?.movedFulfillmentOrder?.id ||
    fulfillmentOrder.id;

  const movedFoRes = await admin.graphql(
    `#graphql
    query GetMovedFulfillmentOrderLineItems($id: ID!) {
      fulfillmentOrder(id: $id) {
        id
        lineItems(first: 100) {
          edges {
            node {
              id
              remainingQuantity
              lineItem {
                id
                sku
                quantity
                product {
                  id
                }
              }
            }
          }
        }
      }
    }`,
    { variables: { id: movedFulfillmentOrderId } },
  );

  const movedFoJson = await movedFoRes.json();
  const movedFo = movedFoJson.data?.fulfillmentOrder;

  if (!movedFo) {
    return new Response(
      JSON.stringify({ error: "Moved fulfillment order not found" }),
      { status: 400 },
    );
  }

  const foItemByProductId = new Map();
  for (const edge of movedFo.lineItems.edges) {
    const node = edge.node;
    const productId = node.lineItem?.product?.id;
    if (productId) {
      foItemByProductId.set(productId, {
        fulfillmentOrderLineItemId: node.id,
        remainingQuantity: node.remainingQuantity,
      });
    }
  }
 
  const lineItemsInput = [];

  for (const line of validLineItems) {
    const productId = line.productId;
    if (!productId) continue;

    const match = foItemByProductId.get(productId);
    if (!match) continue;

    const requestedQty = line.quantity ?? 0;
    const remainingQty = match.remainingQuantity ?? 0;
    const qtyToFulfill = Math.min(requestedQty, remainingQty);
     
    if (qtyToFulfill > 0) {
      lineItemsInput.push({
        id: match.fulfillmentOrderLineItemId,
        quantity: qtyToFulfill,
      });
    }
  }

  if (lineItemsInput.length === 0) {
    return new Response(
      JSON.stringify({
        error:
          "No matching fulfillment order line items to fulfill for your app products.",
      }),
      { status: 400 },
    );
  }

  const fulfillApiRes = await fetch(
    "https://lori-filamentous-seemly.ngrok-free.dev/api/fulfill-order",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId, lineItems: validLineItems }),
    },
  );

  const fulfillApiData = await fulfillApiRes.json();

  if (!fulfillApiRes.ok) {
    return new Response(
      JSON.stringify({
        error: fulfillApiData.error || "Fulfill API failed",
      }),
      { status: 500 },
    );
  }

  const tracking = {
    company: fulfillApiData.carrier,
    number: fulfillApiData.trackingNumber,
    url: fulfillApiData.trackingUrl,
  };

  const fulfillRes = await admin.graphql(
    `#graphql
    mutation fulfillOrderPartially(
      $fulfillmentOrderId: ID!
      $trackingCompany: String!
      $trackingNumber: String!
      $trackingUrl: URL!
      $lineItems: [FulfillmentOrderLineItemInput!]!
    ) {
      fulfillmentCreate(
        fulfillment: {
          lineItemsByFulfillmentOrder: [
            {
              fulfillmentOrderId: $fulfillmentOrderId
              fulfillmentOrderLineItems: $lineItems
            }
          ]
          notifyCustomer: true
          trackingInfo: {
            company: $trackingCompany
            number: $trackingNumber
            url: $trackingUrl
          }
        }
      ) {
        fulfillment {
          id
          status
          trackingInfo {
            company
            number
            url
          }
        }
        userErrors {
          field
          message
        }
      }
    }`,
    {
      variables: {
        fulfillmentOrderId: movedFulfillmentOrderId,
        trackingCompany: tracking.company,
        trackingNumber: tracking.number,
        trackingUrl: tracking.url,
        lineItems: lineItemsInput,
      },
    },
  );

  const fulfillJson = await fulfillRes.json();
  const userErrors = fulfillJson.data?.fulfillmentCreate?.userErrors || [];

  if (userErrors.length > 0) {
    return new Response(JSON.stringify({ error: userErrors[0].message }), {
      status: 400,
    });
  }

  return new Response(
    JSON.stringify({
      success: true,
      trackingUrl: tracking.url,
      carrier: tracking.company,
      trackingNumber: tracking.number,
    }),
    { status: 200 },
  );
}

export default function OrderPage() {
  const { ordersWithCounts } = useLoaderData();
  const fetcher = useFetcher();

  async function handleRequestFulfillment(order) {
    const res = await fetch(
      "https://lori-filamentous-seemly.ngrok-free.dev/api/request-fulfillment",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: order.id,
          lineItems: order.lineItems,
        }),
      },
    );

    const data = await res.json();

    if (!res.ok) {
      alert(data.error);
      return;
    }

    fetcher.submit(
      JSON.stringify({
        orderId: order.id,
        lineItems: order.lineItems,
      }),
      {
        method: "post",
        encType: "application/json",
      },
    );
  }

  if (fetcher.data?.success) {
    alert(`Order fulfilled!\nTracking: ${fetcher.data.trackingUrl}`);
  }

  return (
    <AppProvider>
      <s-page>
        <s-section>
          <s-stack gap="base">
            {ordersWithCounts.map((order) => {
              if (order.lineItemCount === 0) {
                return null;
              }

              return (
                <s-box
                  key={order.id}
                  padding="base"
                  background="transparent"
                  border="base"
                  borderRadius="base"
                  inlineSize="600px"
                >
                  <s-stack direction="block" gap="base">
                    <s-stack
                      direction="inline"
                      alignItems="center"
                      justifyContent="space-between"
                      gap="base"
                    >
                      <s-text>
                        Order {order.name}, Total qty at location:{" "}
                        {order.totalQuantity}
                      </s-text>
                      <s-button onClick={() => handleRequestFulfillment(order)}>
                        Fulfill Order
                      </s-button>
                    </s-stack>

                    <s-stack gap="base">
                      {order.lineItems.map((line, index) => (
                        <s-box
                          key={`${order.id}-${line.inventoryItemId}-${index}`}
                          padding="base"
                          border="base"
                          borderRadius="base"
                        >
                          <s-stack
                            direction="inline"
                            justifyContent="space-between"
                            alignItems="center"
                          >
                            <s-text>
                              {line.productTitle || line.name} (SKU: {line.sku})
                            </s-text>
                            <s-text>
                              Ordered: {line.quantity} | Available at{" "}
                              {line.locationName}: {line.availableAtLocation}
                            </s-text>
                          </s-stack>
                        </s-box>
                      ))}
                    </s-stack>
                  </s-stack>
                </s-box>
              );
            })}
          </s-stack>
        </s-section>
      </s-page>
    </AppProvider>
  );
}