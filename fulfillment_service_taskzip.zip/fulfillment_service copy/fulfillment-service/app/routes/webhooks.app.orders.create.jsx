import { authenticate } from "../shopify.server";
import prisma from "../db.server";

export const action = async ({ request }) => {
  console.log("webhook registration route >>>>>>> Start");

  const { admin, session } = await authenticate.admin(request);
  const shopDomain = session.shop;

  const webhookUri =
    "https://lori-filamentous-seemly.ngrok-free.dev/webhooks/orders/create";

  const createResponse = await admin.graphql(
    `#graphql
    mutation CreateOrdersCreateWebhook(
      $topic: WebhookSubscriptionTopic!
      $webhookSubscription: WebhookSubscriptionInput!
    ) {
      webhookSubscriptionCreate(
        topic: $topic
        webhookSubscription: $webhookSubscription
      ) {
        webhookSubscription {
          id
          topic
          includeFields
          uri
        }
        userErrors {
          field
          message
        }
      }
    }
  `,
    {
      variables: {
        topic: "ORDERS_CREATE",
        webhookSubscription: {
          uri: webhookUri,
          format: "JSON",
        },
      },
    },
  );

  const createJson = await createResponse.json();
  const result = createJson.data?.webhookSubscriptionCreate;
  const errors = result?.userErrors ?? [];

  let webhookId = null;
  let alreadyExists = false;

  if (errors.length) {
    const alreadyTaken = errors.some(
      (e) => e.message === "Address for this topic has already been taken",
    );

    if (alreadyTaken) {
      alreadyExists = true;

      const listResponse = await admin.graphql(
        `#graphql
        query ListOrderCreateWebhooks($topic: WebhookSubscriptionTopic!) {
          webhookSubscriptions(first: 10, topics: [$topic]) {
            edges {
              node {
                id
                topic
                uri
              }
            }
          }
        }
      `,
        {
          variables: {
            topic: "ORDERS_CREATE",
          },
        },
      );

      const listJson = await listResponse.json();
      const edges = listJson.data?.webhookSubscriptions?.edges ?? [];

      const existing = edges
        .map((e) => e.node)
        .find((node) => node.uri === webhookUri);

      if (existing) {
        webhookId = existing.id;
      } else {
        webhookId = null;
      }
    } else {
      return new Response(
        JSON.stringify({
          success: false,
          errors,
        }),
        { status: 400 },
      );
    }
  } else {
    webhookId = result.webhookSubscription.id;
  }

  if (!webhookId) {
    return new Response(
      JSON.stringify({
        success: false,
        errors: [
          {
            field: [],
            message:
              "Unable to determine webhook ID (creation or lookup failed).",
          },
        ],
      }),
      { status: 500 },
    );
  }

  const record = await prisma.orderCreateWebhook.upsert({
    where: {
      shopDomain_topic: {
        shopDomain,
        topic: "ORDERS_CREATE",
      },
    },
    create: {
      shopDomain,
      topic: "ORDERS_CREATE",
      uri: webhookUri,
      webhookGid: webhookId,
    },
    update: {
      uri: webhookUri,
      webhookGid: webhookId,
    },
  });

  return new Response(
    JSON.stringify({
      success: true,
      alreadyExists,
      webhookId,
      webhook: record,
    }),
    { status: 200 },
  );
};
