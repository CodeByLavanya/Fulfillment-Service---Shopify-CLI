import prisma from "../db.server";
import { authenticate } from "../shopify.server";
import { useLoaderData } from "react-router";
import { useState, useEffect } from "react";
import { useFetcher } from "react-router";
// import Styles from "./src/Styles.module.css";

export async function loader({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const addedProducts = await prisma.addedProduct.findMany({
    where: { shop },
    select: { productId: true },
  });

  const addedIds = addedProducts.map((p) => p.productId);

  // console.log(">>>>>>>>addedIdes", addedIds);

  const products = await admin.graphql(
    `#graphql
  query GetProducts {
    products(first: 50) {
      nodes {
       id
          ... on Product {
            title
             featuredImage {
              url
              altText
            }
            variants(first: 10) {
              nodes {
                id
                title
              }
            }
            collections(first: 10) {
              nodes {
                id
                title
              }
            }
          }
      }
    }
  }`,
  );
  const json = await products.json();
  const proIds = json?.data?.products?.nodes;
  // console.log("pro ID first >>>>>>", proIds);

  const notAddedProducts = proIds
    .filter((product) => !addedIds.includes(product.id))
    .map((product) => ({
      id: product.id,
      title: product.title,
      featuredImage: product.featuredImage || null,
    }));
  // console.log("pro ID >>>>>>", notAddedProducts);

  let addeds = [];

  if (addedIds.length > 0) {
    const addedsResponse = await admin.graphql(
      `#graphql
      query GetProductsByIds($ids: [ID!]!) {
        nodes(ids: $ids) {
          id
          ... on Product {
            title

             featuredImage {
              url
              altText
            }
            variants(first: 10) {
              nodes {
                id
                title
                sku
              }
            }
            collections(first: 10) {
              nodes {
                id
                title
              }
            }
          }
        }
      }`,
      {
        variables: {
          ids: addedIds,
        },
      },
    );

    const addedsJson = await addedsResponse.json();
    // console.log("addedsJson", JSON.stringify(addedsJson, null, 2));

    const nodes = addedsJson?.data?.nodes || [];
    // console.log("nodes>>>>>>>", nodes);

    addeds = nodes.map((product) => ({
      id: product.id,
      title: product.title,
      featuredImage: product.featuredImage || null,
      variants: product.variants?.nodes || [],
      skus: product.variants?.nodes?.map((v) => v.sku) || [],
    }));
  }

  // console.log(
  //   "loaderAddednodeq:>>>>>>>>>>",
  //   addeds.map((add) => add.skus),
  // );

  return { addeds, notAddedProducts };
}
export async function action({ request }) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const formData = await request.formData();
  const productId = formData.get("productId");
  const deleteProductId = formData.get("deleteProductId");
  const inventory = formData.get("inventory");
  const Product = formData.get("product");

  if (productId) {
    const existing = await prisma.addedProduct.findFirst({
      where: { shop, productId },
    });

    if (!existing) {
      await prisma.addedProduct.create({
        data: {
          shop,
          productId,
        },
      });
    }

    return null;
  }

  if (deleteProductId) {
    const productRes = await admin.graphql(
      `#graphql
    query getProductInventory($id: ID!) {
      product(id: $id) {
        variants(first: 50) {
          nodes {
            inventoryItem {
              id
            }
          }
        }
      }
    }`,
      {
        variables: { id: deleteProductId },
      },
    );

    const productJson = await productRes.json();
    const inventoryItems = productJson.data?.product?.variants?.nodes || [];

    const fulfillmentService = await prisma.fulfillmentService.findFirst({
      where: { shopDomain: shop },
      select: { id: true },
    });

    const fsResponse = await admin.graphql(
      `#graphql
    query FulfillmentServiceShow($id: ID!) {
      fulfillmentService(id: $id) {
        location {
          id
        }
      }
    }`,
      {
        variables: { id: fulfillmentService.id },
      },
    );

    const fsJson = await fsResponse.json();
    const locationId = fsJson.data?.fulfillmentService?.location?.id;

    for (const variant of inventoryItems) {
      await admin.graphql(
        `#graphql
      mutation setInventory($input: InventorySetOnHandQuantitiesInput!) {
        inventorySetOnHandQuantities(input: $input) {
          userErrors {
            field
            message
          }
        }
      }`,
        {
          variables: {
            input: {
              reason: "correction",
              setQuantities: [
                {
                  inventoryItemId: variant.inventoryItem.id,
                  locationId,
                  quantity: 0,
                },
              ],
            },
          },
        },
      );
    }
    const isExisting = await prisma.addedProduct.findFirst({
      where: { shop, productId: deleteProductId },
    });

    if (isExisting) {
      await prisma.addedProduct.deleteMany({
        where: {
          shop,
          productId: deleteProductId,
        },
      });
    }
    return null;
  }

  if (inventory && Product) {
    console.log("Get Product and Invetory Num", inventory, Product);
    console.log("Get Product and Invetory Num", Product);

    const ProVariantsInventoryId = await admin.graphql(
      `query getInventoryItemId($id: ID!) {
        product(id: $id) {
          id
          totalInventory
          variants(first: 8) {
            nodes {
              title
              inventoryItem {
                id
              }
              inventoryQuantity
            }
          }
        }
      }`,
      {
        variables: {
          id: Product,
        },
      },
    );

    const idJson = await ProVariantsInventoryId.json();
    const variantIds = idJson.data?.product?.variants?.nodes;

    const variantId = variantIds.map((node) => node.inventoryItem);

    console.log("varients", variantId);
    const FulfillmenId = await prisma.fulfillmentService.findFirst({
      where: {
        shopDomain: shop,
      },
      select: {
        id: true,
      },
    });
    console.log("fulfilll>>>>>>>>>>>", FulfillmenId);

    const fsResponse = await admin.graphql(
      `#graphql
     query FulfillmentServiceShow($id: ID!) {
       fulfillmentService(id: $id) {
         id
         location {
           id
         }
       }
     }`,
      {
        variables: {
          id: FulfillmenId.id,
        },
      },
    );

    const fsJson = await fsResponse.json();
    const locationId = fsJson.data?.fulfillmentService?.location?.id;

    for (const variantIds of variantId) {
      const updateInventory = await admin.graphql(
        `#graphql
    mutation AdjustQuantity($input: InventoryAdjustQuantitiesInput!) {
      inventoryAdjustQuantities(input: $input) {
        inventoryAdjustmentGroup {
          id
          changes {
            delta
          }
        }
        userErrors {
          field
          message
        }
      }
    }
    `,
        {
          variables: {
            input: {
              name: "available",
              reason: "correction",
              changes: [
                {
                  inventoryItemId: variantIds.id,
                  locationId: locationId,
                  delta: Number(inventory),
                },
              ],
            },
          },
        },
      );

      const inventoryQuantity = await updateInventory.json();
      console.log("inventory>>>>>>>>>>", inventoryQuantity);
    }
  }
}

export default function addProductsPage() {
  const fetcher = useFetcher();
  const { addeds = [], notAddedProducts = [] } = useLoaderData() || {};
  const [addedIds, setAddedIds] = useState(addeds.map((p) => p.id));
  // const [selectedIds, setSelectedIds] = useState([]);

  const handleAddProducts = async (productId) => {
    if (!addedIds.includes(productId)) {
      setAddedIds((prev) => [...prev, productId]);
    }

    fetcher.submit({ productId }, { method: "POST" });
  };

  const handleDeleteProduct = async (deleteProductId) => {
    setAddedIds((prev) => prev.filter((id) => id !== deleteProductId));
    fetcher.submit({ deleteProductId }, { method: "POST" });
  };

  const handleUpdateInventory = async (pro) => {
    let sku = pro.skus[0];
    console.log("sku", sku);

    try {
      const response = await fetch(
        "https://lori-filamentous-seemly.ngrok-free.dev/api/inventory",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ sku, pro }),
        },
      );

      const result = await response.json();
      console.log("Inventory result:", result);
      const Product = result.pro;
      const inventory = result.inventory;

      const ProId = Product.id;

      fetcher.submit(
        {
          inventory: inventory,
          product: ProId,
        },
        { method: "POST" },
      );
    } catch (error) {
      console.error("Inventory update failed :", error);
    }
  };

  return (
    <s-page heading="Products">
      <s-section>
        <s-stack gap="base">
          {addeds.map((product) => (
            <s-box
              key={product.id}
              padding="base"
              background="transparent"
              border="base"
              borderRadius="base"
              inlineSize="600px"
            >
              <s-stack
                direction="inline"
                alignItems="center"
                justifyContent="flex-start"
                gap="base"
              >
                <s-thumbnail
                  size="small"
                  src={product.featuredImage?.url ?? ""}
                  alt={product.featuredImage?.altText ?? product.title}
                />
                <s-text>{product.title}</s-text>
                <s-button
                  variant="secondary"
                  tone="neutral"
                  onClick={() => handleUpdateInventory(product)}
                >
                  Update Inventory
                </s-button>
                <s-button
                  variant="secondary"
                  tone="critical"
                  onClick={() => handleDeleteProduct(product.id)}
                >
                  Delete
                </s-button>
              </s-stack>
            </s-box>
          ))}
        </s-stack>

        <s-button variant="secondary" commandFor="modal">
          Add Products
        </s-button>
      </s-section>
      <s-modal id="modal" heading="Products">
        {notAddedProducts.length === 0 ? (
          <div>All Products Added to Fulfillment service</div>
        ) : (
          <div>
            {notAddedProducts.map((product) => (
              <s-box
                key={product.id}
                padding="base"
                background="transparent"
                border="base"
                borderRadius="base"
                inlineSize="600px"
              >
                <s-stack
                  direction="inline"
                  alignItems="center"
                  justifyContent="space-around"
                  gap="base"
                >
                  <s-thumbnail
                    size="small"
                    src={product.featuredImage?.url ?? ""}
                    alt={product.featuredImage?.altText ?? product.title}
                  />
                  <s-text>{product.title}</s-text>
                  <s-button
                    variant="primary"
                    onClick={() => handleAddProducts(product.id)}
                  >
                    Add
                  </s-button>
                </s-stack>
              </s-box>
            ))}
          </div>
        )}
      </s-modal>
      <s-app-nav>
        <s-link href="/dashBoardProductPage">Product Page</s-link>
        <s-link href="/orderPage">OrderPage</s-link>
      </s-app-nav>
    </s-page>
  );
}
