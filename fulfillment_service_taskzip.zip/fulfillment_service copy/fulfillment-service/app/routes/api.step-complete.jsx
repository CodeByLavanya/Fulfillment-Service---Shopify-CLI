import prisma from "../db.server";
import { authenticate } from "../shopify.server";

export const action = async ({ request }) => {
  if (request.method !== "POST") {
    return new Response(
      JSON.stringify({ success: false, error: "Method not allowed" }),
      { status: 405 }
    );
  }

  try {
    const { session } = await authenticate.admin(request);
    const shop = session.shop;

    const body = await request.json();
    const step = body.stepComplete;

    if (typeof step !== "number") {
      return new Response(
        JSON.stringify({ success: false, error: "Invalid step value" }),
        { status: 400 }
      );
    }

    const record = await prisma.stepComplete.upsert({
      where: { shopDomain: shop },
      update: { stepComplete: step },
      create: {
        shopDomain: shop,
        stepComplete: step,
      },
    });

    return {
      success: true,
      stepComplete: record.stepComplete,
    };
  } catch (error) {
    console.error("Error updating stepComplete:", error);
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { status: 500 }
    );
  }
};
