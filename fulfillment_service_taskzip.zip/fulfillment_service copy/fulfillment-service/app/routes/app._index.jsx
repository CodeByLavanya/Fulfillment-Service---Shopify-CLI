import { useNavigate } from "react-router";
import { authenticate } from "../shopify.server";
import prisma from "../db.server";
import { useEffect } from "react";
import { useLoaderData } from "react-router";

export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);

  const record = await prisma.stepComplete.findFirst({
    where: {
      shopDomain: session.shop,
    },
    select: {
      stepComplete: true,
    },
  });

  return {
    stepComplete: record?.stepComplete ?? 0,
  };
};

export default function Index() {
  const navigate = useNavigate();
  const { stepComplete } = useLoaderData();
  useEffect(() => { 
    if (stepComplete === 1) {
      navigate("/addProductPage");
    } else if (stepComplete >= 2) {
      navigate("/dashBoard");
    }
  }, [stepComplete, navigate]);

  const setCarrier = async () => {
    try {
      const carrierResponse = await fetch("/api/carrierService", {
        method: "POST",
      });

      const carrierResult = await carrierResponse.json();
      console.log("Response:", carrierResult);

      const fulfillmentResponse = await fetch("/api/fulFillmentService", {
        method: "POST",
      });

      const fulfillmentResult = await fulfillmentResponse.json();
      console.log("Response:", fulfillmentResult);

      console.log("start hooks");
      const webhookResponse = await fetch("/webhooks/app/orders/create", {
        method: "POST",
      });

      const webhookResult = await webhookResponse.json();

      if (webhookResult.success) {
        if (webhookResult.alreadyExists) {
          console.log(
            "ORDERS_CREATE webhook already exists with ID:",
            webhookResult.webhookId,
          );
        } else {
          console.log(
            "Created ORDERS_CREATE webhook with ID:",
            webhookResult.webhookId,
          );
        }
      } else {
        console.error("Failed to create webhook:", webhookResult.errors);
      }

      const response = await fetch("/api/step-complete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ stepComplete: 1 }),
      });

      const result = await response.json();
      console.log("step updated:", result);

      if (result.success) {
        navigate("/addProductPage");
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <s-page heading="Shopify app template">
      <s-section>
        <ul>
          <li>Create a Carrier Service</li>
          <li>Create a Fulfillment Service</li>
          <li>Register an Order Created webhook</li>
        </ul>
        <s-button variant="primary" onClick={setCarrier}>
          Setup and Continue
        </s-button>
      </s-section>
    </s-page>
  );
}
